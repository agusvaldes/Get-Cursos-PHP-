<?php
function get_cursos()
{
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    set_time_limit(0);

    require_once('ripcord/ripcord.php'); //download from here https://code.google.com/p/ripcord/
    $datos_conexion = array(
             'host' => 'isoges.isonor.es',
             'database' => 'isonor',
             'user' => 'web_formanor_acceso_cursos_publicos',
             'password' => 'ooK3Aeboc3&faeXe3iz9u');

    //login
    $common = ripcord::client('https://' . $datos_conexion['host'] . '/xmlrpc/2/common');
    $uid = $common->authenticate($datos_conexion['database'], $datos_conexion['user'], $datos_conexion['password'], array());

    $models = ripcord::client('https://' . $datos_conexion['host'] . "/xmlrpc/2/object");

    //buscando cursos
    $cursos= $models->execute_kw($datos_conexion['database'], $uid, $datos_conexion['password'], 'iso_iso_formation.calendar_event', 'search', array(array(array(1, '=', 1))), array('limit'=>7));
    $data = $models->execute_kw($datos_conexion['database'], $uid, $datos_conexion['password'], 'iso_iso_formation.calendar_event', 'read', array($cursos), array('fields'=>array( 'date_start', 'date_end', 'mode', 'aula', 'name', 'teacher_calendar_config_id', 'calendar_config_id', 'company_id', 'analytic_tag_id' ) ));

    return $data;
}

function get_cursor_mysql()   //Esta es la funcion que me tengo que hacer cargo yo
{
    require_once('../wp-config.php');
    global $wpdb;
	$table = $wpdb->prefix.'fmn_posts';
	$format = array('%s','%d');

	foreach ($data as $dato)
	{
		$data = array('post_title' => $cursos['name'], 'id' => 0);
		$wpdb->insert($table, $data, $format);
	}
}
///////////////////////////////////////////////////////////////////////////

$cursos = get_cursos();
echo 'Tenemos '.count($cursos).' cursos.';
$cr = get_cursor_mysql();


?>
